# JRF 2026 Voucher Claim — Handoff for Claude Code

Build a voucher-claim landing page plus its backend for Jakarta Running Festival (JRF) 2026 runners on sneakersflash.com.

- **Stack:** SneakersFlash 2.0 (NestJS + Prisma + PostgreSQL backend, Next.js frontend).
- **Follow existing conventions:** module/service/controller/DTO structure, mock factories in tests, `@jest/globals` imports.
- **Don't greenfield:** read the existing voucher/promo, cart and checkout code first and extend it.

## Reference files (this folder)

- `index.html` — approved UI and copy. It covers the full layout: hero, form, steps, T&C, FAQ and success popup.
  - Port it to a Next.js page (suggested route: `/jrf2026`).
  - Keep the copy exactly as written.
  - It already contains the frontend validation, the category→nominal preview, the upload checks and the popup behavior.
  - `verifyClaim()` in it is a DEMO mock. Replace it with the real API.
- `assets/jrf-start.jpg` — hero / popup background photo.
- `assets/jrf-logo.png` — Jakarta Running Fest 2026 logo (white, transparent). Used in the navbar, the hero and the popup header.

## Navbar brief

- **Left:** a co-brand lockup.
  - Official **Sneakers Flash logo, WHITE version** (SVG preferred, transparent). Height ~28px desktop / 22px mobile, links to `/`.
  - Then a 1px divider (#4A4A4A, 30px tall).
  - Then the JRF 2026 logo, height ~32px desktop / 26px mobile.
- **Right:** the pill "JRF 2026 · RUNNER EXCLUSIVE". Hide it under 640px.
- **Background:** black (#0A0A0A). Never use the black logo variant ("Logo Full Hitam") here.
- **Placeholder:** `index.html` currently shows a text wordmark "SNEAKERS FLASH" (marked `TODO`). Replace it with the logo file from the existing Next.js codebase / brand assets.

## Voucher tiers

| Category | Code prefix | Nominal (fixed amount) | Min. purchase (eligible subtotal) | Excluded |
|---|---|---|---|---|
| 5K | `JRF5K-` | Rp150.000 | Rp2.000.000 | apparel, clearance sale |
| 10K | `JRF10K-` | Rp250.000 | Rp2.000.000 | apparel, clearance sale |
| HM (21K) | `JRFHM-` | Rp350.000 | Rp2.000.000 | apparel, clearance sale |
| FM (42K) | `JRFFM-` | Rp500.000 | Rp2.000.000 | apparel, clearance sale |

Campaign rules:

- **Claim window:** 22–29 Oct 2026, Asia/Jakarta (WIB).
- **Validity:** 14 days from `claimed_at`.
- **Channel:** sneakersflash.com only.
- **Limits:** 1 BIB = 1 claim = 1 code = 1 transaction. No cash value.

## Claim flow (backend)

`POST /jrf/claim`, multipart: `nama, phone, email, bib, category (5K|10K|HM|FM), screenshot (jpg/png ≤5MB), agree`

1. Reject if the request falls outside the claim window → `CLOSED`.
2. Reject if the BIB has already claimed (unique constraint on `bib`) → `BIB_USED`.
3. Store the screenshot. Verify nama + BIB + category against it → `DATA_MISMATCH` / `BAD_SCREENSHOT` on failure.
   - **Open question:** manual CS review or OCR? If manual, the claim is `PENDING` and the code is issued later.
4. On pass, issue a unique single-use code: `prefix + 6 random A-Z0-9`, with the nominal from the tier and `expired_at = claimed_at + 14d`.
5. Return `{ ok, code, category, nominal, expiredAt }`. The frontend shows it in the popup.

Error copy, keyed by error code (already wired in `index.html` `ERRORS`):

- **BIB_USED:** "Nomor BIB ini sudah pernah digunakan untuk claim voucher."
- **DATA_MISMATCH:** "Data belum berhasil diverifikasi. Cek kembali nama, nomor BIB, kategori race, dan bukti peserta."
- **BAD_SCREENSHOT:** "Screenshot kurang jelas atau tidak sesuai. Coba upload ulang bukti kepesertaan dari aplikasi JRF."
- **CLOSED:** "Periode claim voucher JRF 2026 sudah berakhir pada 29 Oktober 2026."

Suggested Prisma model `JrfVoucherClaim`:

- **Fields:** `id, bib @unique, category, nama, phone, email, screenshotUrl, voucherCode @unique, nominal Int, claimedAt, expiredAt, status (PENDING|ISSUED|USED|EXPIRED|REJECTED), orderId?`
- **Reuse first:** if a voucher/promo table already exists, link to it instead of duplicating.

## Checkout logic

```
eligible_items    = cart.items.filter(i => !i.isApparel && !i.isClearance)
eligible_subtotal = sum(eligible_items.price * qty)   // after product discount, before shipping
if eligible_subtotal < 2_000_000 → reject
discount = min(voucher.nominal, eligible_subtotal)
```

- **Flags:** apparel comes from the product category master; clearance comes from an active clearance tag/collection. Neither is set manually.
- **Excluded from the eligible subtotal:** shipping, service fee and insurance.
- **Re-validate:** if a cart change drops the eligible subtotal below Rp2.000.000, detach the voucher and show an error.
- **Mark used:** set the code to `USED` + `orderId` on order creation. Codes are not restored on cancel/refund (pending confirmation).

Checkout error copy:

- **Below minimum:** "Belanja produk eligible min. Rp2.000.000 untuk pakai voucher ini. Apparel & clearance sale tidak dihitung."
- **Only excluded items in cart:** "Voucher tidak berlaku untuk apparel dan produk clearance sale."
- **Code already used:** "Kode voucher ini sudah digunakan."
- **Expired:** "Kode voucher sudah kedaluwarsa."

## Open items — confirm with business before go-live

- [ ] Stacking with Flash Point / other promos allowed?
- [ ] Apparel/clearance exclusion confirmed for FM too
- [ ] Min. purchase basis: after product discount, before shipping (assumed)
- [ ] Screenshot verification: manual vs OCR
- [ ] WhatsApp/email code delivery — only claim "kode dikirim" in the UI once it is live and tested
- [ ] Total quota / budget cap per category
- [ ] Usage rights for the event photo; avoid "official partner" wording

## Suggested order of work

1. Explore the existing promo/voucher, cart and checkout modules. Report how vouchers work today before changing anything.
2. Add the Prisma model + migration, then the claim endpoint with validation, file upload and rate limiting.
3. Add the checkout eligibility logic, with unit tests for each tier, each exclusion, the min-purchase edge (1.999.999 vs 2.000.000), expired and used cases.
4. Build the Next.js `/jrf2026` page from `index.html` and wire it to the API.
5. Add an admin/CS view to review PENDING claims (if manual verification).
